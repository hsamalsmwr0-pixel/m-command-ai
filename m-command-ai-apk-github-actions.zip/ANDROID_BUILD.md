# M-Command AI — Android APK via GitHub Actions

This repository is configured to build an Android debug APK from the existing Vite/React app.

## How it works

GitHub Actions will:

1. Install Node.js and Java.
2. Install the JavaScript dependencies.
3. Build the Vite app into `dist/`.
4. Generate the Android platform with Capacitor 8.
5. Sync `dist/` into the Android project.
6. Build `app-debug.apk` with Gradle.
7. Upload the APK as a GitHub Actions artifact.

## Run the build

Open the repository on GitHub, go to **Actions**, select **Build M-Command AI Android APK**, and choose **Run workflow**.

After the workflow succeeds, open the workflow run and download the artifact named:

`m-command-ai-debug-apk`

The artifact contains:

`app-debug.apk`

## App identity

- App name: M-Command AI
- Android application ID: `com.mcommand.ai`
- Web build directory: `dist`

## Important

This workflow intentionally produces a **debug APK** for testing. A production/release APK should later use a signing key stored in GitHub Actions Secrets; never place a keystore or passwords directly in the repository.
